# HTTP5225-assignment1
This assignment displays active NBA players. It features a join query that shows data about the team the player plays for.

## Data
The data for the two tables can be found in the tables folder in CSV format.
