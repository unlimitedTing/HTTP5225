<?php 
    // Enable error reporting
    $servername = "127.0.0.1";
    $username = "root";
    $password = "root";
    $dbname = "http5225-assignment1"; 
    $port = 8889;

    // Create connection
    $connect = new mysqli($servername, $username, $password, $dbname, $port);

    // Check connection
    if ($connect->connect_error) {
        die("Connection failed: " . $connect->connect_error);
    }
?>
